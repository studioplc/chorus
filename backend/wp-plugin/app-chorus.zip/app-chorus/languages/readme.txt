Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_chorus-de_DE.po
* app_chorus-id_ID.po
* app_chorus_ES.po
* app_chorus-en_US.po
* app_chorus-de_DE.mo
* app_chorus-id_ID.mo
* app_chorus-es_ES.mo
* app_chorus-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
